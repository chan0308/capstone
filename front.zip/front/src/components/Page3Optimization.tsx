import { useState, useRef } from "react";
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  Radar, ResponsiveContainer, Tooltip, BarChart, Bar,
  XAxis, YAxis, CartesianGrid
} from "recharts";
import { TrendingDown, Zap, AlertCircle, Target } from "lucide-react";
import { Cell } from "recharts";

/* ============================================================
   1) CUSTOM VERTICAL SLIDER COMPONENT (OPTION B)
============================================================ */

function VerticalSlider({
  label,
  value,
  setValue,
  min,
  max,
  color
}: {
  label: string;
  value: number;
  setValue: (v: number) => void;
  min: number;
  max: number;
  color: string;
}) {
  const trackRef = useRef<HTMLDivElement | null>(null);

  const handleDrag = (clientY: number) => {
    if (!trackRef.current) return;

    const rect = trackRef.current.getBoundingClientRect();
    const offset = clientY - rect.top;
    const ratio = 1 - Math.min(Math.max(offset / rect.height, 0), 1);
    const newValue = min + ratio * (max - min);

    setValue(parseFloat(newValue.toFixed(2)));
  };

  const startDrag = (e: any) => {
    e.preventDefault();
    handleDrag(e.clientY || e.touches?.[0]?.clientY);

    const move = (ev: any) => handleDrag(ev.clientY || ev.touches?.[0]?.clientY);
    const stop = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("mouseup", stop);
      window.removeEventListener("touchend", stop);
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("touchmove", move);
    window.addEventListener("mouseup", stop);
    window.addEventListener("touchend", stop);
  };

  const percent = ((value - min) / (max - min)) * 100;

  return (
    <div className="flex flex-col items-center">
      <span className="text-sm font-semibold text-black mb-1">{label}</span>

      <div
        ref={trackRef}
        className="relative w-3 bg-gray-200 rounded-full"
        style={{ height: 240 }}
      >
        {/* active fill */}
        <div
          className="absolute bottom-0 left-0 w-full rounded-full"
          style={{ height: `${percent}%`, backgroundColor: color }}
        />

        {/* thumb */}
        <div
          onMouseDown={startDrag}
          onTouchStart={startDrag}
          className="absolute left-1/2 -translate-x-1/2 w-6 h-6 bg-white border shadow rounded-full cursor-pointer flex items-center justify-center"
          style={{ bottom: `calc(${percent}% - 12px)` }}
        >
          <div className="w-2 h-2 bg-gray-800 rounded-full" />
        </div>
      </div>

      <span className="mt-2 text-sm font-bold">{value.toFixed(2)}</span>
    </div>
  );
}

/* ============================================================
   2) MAIN PAGE
============================================================ */

export default function Page3Optimization() {
  /* SLIDER STATE */
  const [pValue, setPValue] = useState(0.12);
  const [aValue, setAValue] = useState(0.53);
  const [fValue, setFValue] = useState(0.35);

  /* CALCULATE COQ */
  const calculateCOQ = (p: number, a: number, f: number) =>
    Math.max(
      0.5,
      Math.min(
        5,
        3.5 + (1.12 * p * 10) - (2.84 * a * 10) - (0.95 * f * 10)
      )
    );

  const currentCOQ = calculateCOQ(pValue, aValue, fValue);

  /* OPTIMAL ZONE */
  const isOptimal =
    pValue >= 0.18 &&
    pValue <= 0.24 &&
    aValue >= 0.40 &&
    aValue <= 0.46 &&
    fValue >= 0.34 &&
    fValue <= 0.38;

  /* COQ Chart Data (simple 3-line P/A/F + highlight band) */
  const pafTrendData = [
    { name: "P", value: pValue },
    { name: "A", value: aValue },
    { name: "F", value: fValue },
    { name: "COQ", value: currentCOQ }
  ];

  /* ElasticNet */
  const elasticNetData = [
    { label: "Prevention", coefficient: 1.12, color: "#737373" },
    { label: "Appraisal", coefficient: -2.84, color: "#dc2626" },
    { label: "Failure", coefficient: -0.95, color: "#737373" }
  ];

  /* Sensitivity */
  const sensitivityData = [
    { label: "A -10%", value: -0.28 },
    { label: "P -5%", value: -0.06 },
    { label: "F +5%", value: 0.02 }
  ];

  /* Radar */
  const radarData = [
    { metric: "Prevention", Current: pValue, Optimal: 0.21, Theoretical: 0.30 },
    { metric: "Appraisal", Current: aValue, Optimal: 0.43, Theoretical: 0.20 },
    { metric: "Failure", Current: fValue, Optimal: 0.36, Theoretical: 0.50 }
  ];

  const insights = [
    "Tesla is appraisal-heavy",
    "Optimal zone → reduce A, adjust P moderately",
    "A reduction yields largest COQ improvement",
    "Theoretical optimum is unrealistic"
  ];

  return (
    <div className="max-w-[1700px] mx-auto px-10 py-12">

      {/* HEADER */}
      <h1 className="text-5xl font-bold mb-10 text-black">Quality Cost Optimization</h1>

      {/* ========================= ROW 1 ========================= */}
      <div className="grid grid-cols-[220px,1fr,260px] gap-10 mb-16">

        {/* LEFT — SLIDERS */}
        <div className="flex flex-col items-center gap-10 bg-white rounded-3xl p-8 border shadow">
          <VerticalSlider
            label="Prevention"
            value={pValue}
            setValue={setPValue}
            min={0.1}
            max={0.3}
            color="#6b7280"
          />
          <VerticalSlider
            label="Appraisal"
            value={aValue}
            setValue={setAValue}
            min={0.2}
            max={0.6}
            color="#525252"
          />
          <VerticalSlider
            label="Failure"
            value={fValue}
            setValue={setFValue}
            min={0.2}
            max={0.5}
            color="#dc2626"
          />
        </div>

        {/* CENTER — COQ CHART */}
        <div className="bg-white rounded-3xl p-8 border shadow">

          {/* COQ VALUE */}
          <div className="text-center mb-8">
            <p className="text-gray-700 text-sm mb-2">Calculated COQ Ratio</p>
            <div className="text-7xl font-bold">{currentCOQ.toFixed(2)}</div>
            <p className="mt-3 text-sm font-semibold">
              {isOptimal ? "✓ Inside Optimal Zone" : "○ Outside Optimal Zone"}
            </p>
          </div>

          {/* Chart */}
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={pafTrendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />

              <XAxis dataKey="name" />
              <YAxis domain={[0, 1]} />

              <Tooltip />

              <Bar dataKey="value">
                {pafTrendData.map((d, i) => (
                  <Cell
                    key={i}
                    fill={
                      d.name === "P"
                        ? "#6b7280"
                        : d.name === "A"
                        ? "#525252"
                        : d.name === "F"
                        ? "#dc2626"
                        : "#9ca3af"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* RIGHT — OPTIMAL ZONE */}
        <div className="bg-green-50 rounded-3xl p-8 border border-green-200 shadow">
          <h3 className="text-xl font-bold mb-6">Where Should Tesla Move?</h3>

          {[
            ["Prevention (P)", "0.18 – 0.24"],
            ["Appraisal (A)", "0.40 – 0.46"],
            ["Failure (F)", "0.34 – 0.38"]
          ].map(([label, val], i) => (
            <div
              key={i}
              className="bg-white p-4 rounded-xl border mb-4 text-center"
            >
              <p className="text-xs text-gray-600">{label}</p>
              <p className="text-xl text-green-700 font-bold">{val}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ========================= ROW 2 ========================= */}
      <div className="grid grid-cols-2 gap-10 mb-16">

        {/* LEFT — ELASTICNET */}
        <div className="bg-white rounded-3xl p-8 border shadow">
          <h3 className="text-xl font-bold mb-6">What drives bad COQ?</h3>

          <div className="grid grid-cols-[1fr,180px] gap-6">
            {/* Chart */}
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={elasticNetData} layout="vertical">
                <XAxis type="number" hide />
                <YAxis dataKey="label" type="category" width={80} />
                <Bar dataKey="coefficient">
                  {elasticNetData.map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>

            {/* Text */}
            <div className="flex flex-col justify-center text-sm text-gray-700">
              <p className="font-semibold">• A(Appraisal)이 가장 강한 영향</p>
              <p className="mt-1">• Appraisal 감소가 COQ 개선의 핵심</p>
            </div>
          </div>
        </div>

        {/* RIGHT — SENSITIVITY */}
        <div className="bg-white rounded-3xl p-8 border shadow">
          <h3 className="text-xl font-bold mb-6">Which change reduces COQ the most?</h3>

          <div className="grid grid-cols-[1fr,180px] gap-6">
            {/* "Waterfall-like" bars */}
            <div>
              {sensitivityData.map((d, i) => (
                <div key={i} className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>{d.label}</span>
                    <span
                      className={`font-bold ${
                        d.value < 0 ? "text-red-600" : "text-gray-600"
                      }`}
                    >
                      {d.value}
                    </span>
                  </div>

                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${
                        d.value < 0 ? "bg-red-600" : "bg-gray-500"
                      }`}
                      style={{ width: `${Math.abs(d.value) * 200}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Bullets */}
            <div className="text-sm text-gray-700 flex flex-col justify-center">
              <p>• A -10% → COQ 큰 폭 개선</p>
              <p>• P -5% → COQ 소폭 개선</p>
              <p>• F 변화 → 영향 적음</p>
            </div>
          </div>
        </div>
      </div>

      {/* ========================= ROW 3 ========================= */}
      <div className="grid grid-cols-[60%,40%] gap-10">

        {/* LEFT — RADAR */}
        <div className="bg-white rounded-3xl p-8 border shadow">
          <h3 className="text-xl font-bold mb-4">Current vs Optimal vs Theoretical</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="metric" />
              <PolarRadiusAxis domain={[0, 0.6]} />
              <Radar dataKey="Current" stroke="#dc2626" fill="#dc2626" fillOpacity={0.3} />
              <Radar dataKey="Optimal" stroke="#22c55e" fill="#22c55e" fillOpacity={0.2} />
              <Radar dataKey="Theoretical" stroke="#737373" fill="#737373" fillOpacity={0.1} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* RIGHT — INSIGHTS */}
        <div className="bg-red-50 rounded-3xl p-8 border border-red-200 shadow">
          <h3 className="text-xl font-bold mb-4">Key Insights</h3>

          <div className="space-y-4">
            {insights.map((txt, i) => (
              <div key={i} className="bg-white p-4 rounded-xl border text-sm">
                {txt}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}