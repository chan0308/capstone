import { motion } from "motion/react";
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

// 오른쪽 최적 비율 카드용 컴포넌트
interface RatioCardProps {
  label: string;
  value: string;
  delta: string;
  direction: "up" | "down";
}

function RatioCard({ label, value, delta, direction }: RatioCardProps) {
  const isUp = direction === "up";
  const colorClass = isUp ? "text-red-500" : "text-gray-500";
  const bgClass = "bg-white";

  return (
    <div
      className={`${bgClass} rounded-2xl shadow-md px-5 py-4 flex items-center justify-between`}
    >
      <div className="flex flex-col gap-1">
        <span className="text-xs text-gray-500 font-medium">{label}</span>
        <span className="text-2xl font-bold text-black">{value}</span>
      </div>
      <div className="flex items-center gap-2 rounded-2xl bg-gray-50 px-3 py-2 shadow-sm">
        <div className="w-8 h-5 flex items-center justify-center">
          {isUp ? (
            <ArrowUpRight className="w-4 h-4 text-red-500" />
          ) : (
            <ArrowDownRight className="w-4 h-4 text-gray-500" />
          )}
        </div>
        <span className={`text-xs font-semibold ${colorClass}`}>{delta}</span>
      </div>
    </div>
  );
}

export default function Page1COQOverview() {
  // P/A/F 비율 구조 (2020.01~2025.04) – 기존 더미 데이터를 그대로 사용
  const pafData = [
    { month: "Jan 20", P: 0.28, A: 0.38, F: 0.34 },
    { month: "Apr 20", P: 0.27, A: 0.39, F: 0.34 },
    { month: "Jul 20", P: 0.26, A: 0.4, F: 0.34 },
    { month: "Oct 20", P: 0.25, A: 0.41, F: 0.34 },
    { month: "Jan 21", P: 0.24, A: 0.42, F: 0.34 },
    { month: "Apr 21", P: 0.23, A: 0.43, F: 0.34 },
    { month: "Jul 21", P: 0.22, A: 0.44, F: 0.34 },
    { month: "Oct 21", P: 0.21, A: 0.45, F: 0.34 },
    { month: "Jan 22", P: 0.2, A: 0.46, F: 0.34 },
    { month: "Apr 22", P: 0.19, A: 0.47, F: 0.34 },
    { month: "Jul 22", P: 0.18, A: 0.48, F: 0.34 },
    { month: "Oct 22", P: 0.17, A: 0.48, F: 0.35 },
    { month: "Jan 23", P: 0.16, A: 0.49, F: 0.35 },
    { month: "Apr 23", P: 0.15, A: 0.5, F: 0.35 },
    { month: "Jul 23", P: 0.14, A: 0.51, F: 0.35 },
    { month: "Oct 23", P: 0.14, A: 0.51, F: 0.35 },
    { month: "Jan 24", P: 0.13, A: 0.52, F: 0.35 },
    { month: "Apr 24", P: 0.13, A: 0.52, F: 0.35 },
    { month: "Jul 24", P: 0.12, A: 0.53, F: 0.35 },
    { month: "Oct 24", P: 0.12, A: 0.53, F: 0.35 },
  ];

  // 최근 3개월 도넛 차트용 – 일단 마지막 값 기준으로 구성
  const latest = pafData[pafData.length - 1];
  const recentPieData = [
    { name: "Prevention (P)", value: latest.P },
    { name: "Appraisal (A)", value: latest.A },
    { name: "Failure (F)", value: latest.F },
  ];

  // COQ Efficiency 더미 데이터
  const efficiencyData = [
    { month: "Jan 20", efficiency: 3.1 },
    { month: "Apr 20", efficiency: 3.0 },
    { month: "Jul 20", efficiency: 2.9 },
    { month: "Oct 20", efficiency: 2.8 },
    { month: "Jan 21", efficiency: 2.7 },
    { month: "Apr 21", efficiency: 2.6 },
    { month: "Jul 21", efficiency: 2.5 },
    { month: "Oct 21", efficiency: 2.4 },
    { month: "Jan 22", efficiency: 2.3 },
    { month: "Apr 22", efficiency: 2.2 },
    { month: "Jul 22", efficiency: 2.1 },
    { month: "Oct 22", efficiency: 2.0 },
    { month: "Jan 23", efficiency: 1.95 },
    { month: "Apr 23", efficiency: 1.9 },
    { month: "Jul 23", efficiency: 1.87 },
    { month: "Oct 23", efficiency: 1.85 },
    { month: "Jan 24", efficiency: 1.83 },
    { month: "Apr 24", efficiency: 1.81 },
    { month: "Jul 24", efficiency: 1.79 },
    { month: "Oct 24", efficiency: 1.78 },
  ];

  // Efficiency Timeline
  const timeline = [
    { year: 2020, status: "개선" },
    { year: 2021, status: "중립" },
    { year: 2022, status: "안정" },
    { year: 2023, status: "개선" },
    { year: 2024, status: "중립" },
    { year: 2025, status: "개선" },
  ];

  return (
    <div className="min-h-screen bg-[#f5f5f7] px-10 py-10">
      {/* 헤더 */}
      <motion.header
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-extrabold text-black mb-2">
          Tesla 현재 품질비용 구조
        </h1>
        <p className="text-sm font-semibold">
          <span className="text-red-500 mr-1">Where Should Tesla Move?</span>
          <span className="text-gray-700">(Optimal Ratio)</span>
        </p>
      </motion.header>

      {/* 상단 큰 카드: Area + Donut + KPI 카드 */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05, duration: 0.4 }}
        className="bg-white rounded-[32px] shadow-lg px-8 py-6 mb-7 flex gap-8 items-stretch"
      >
        {/* 좌측 – COQ 비율 구조 AreaChart */}
        <div className="flex-1 flex flex-col">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">
            COQ 비율 구조 (2020.01 - 2025.04)
          </h3>
          <div className="flex-1">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={pafData}>
                <defs>
                  <linearGradient id="areaF" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97373" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#f97373" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="areaA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#fbbf77" stopOpacity={0.9} />
                    <stop offset="95%" stopColor="#fbbf77" stopOpacity={0.15} />
                  </linearGradient>
                  <linearGradient id="areaP" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#facc93" stopOpacity={0.9} />
                    <stop offset="95%" stopColor="#facc93" stopOpacity={0.2} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(0,0,0,0.06)"
                />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 10, fill: "#737373" }}
                  axisLine={{ stroke: "#e5e7eb" }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "#737373" }}
                  axisLine={{ stroke: "#e5e7eb" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(255,255,255,0.95)",
                    borderRadius: 16,
                    border: "1px solid rgba(0,0,0,0.08)",
                    padding: "10px 12px",
                  }}
                  labelStyle={{ fontSize: 11, color: "#4b5563" }}
                  itemStyle={{ fontSize: 11, color: "#111827" }}
                />
                {/* stacked area – 순서 중요(F가 위로 올라가도록) */}
                <Area
                  type="monotone"
                  dataKey="P"
                  stackId="1"
                  stroke="#f59e0b"
                  fill="url(#areaP)"
                />
                <Area
                  type="monotone"
                  dataKey="A"
                  stackId="1"
                  stroke="#fb923c"
                  fill="url(#areaA)"
                />
                <Area
                  type="monotone"
                  dataKey="F"
                  stackId="1"
                  stroke="#ef4444"
                  strokeWidth={2}
                  fill="url(#areaF)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#facc93]" />
              <span className="text-[11px] text-gray-700 font-medium">
                Prevention_Ratio
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#fbbf77]" />
              <span className="text-[11px] text-gray-700 font-medium">
                Appraisal_Ratio
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#ef4444]" />
              <span className="text-[11px] text-gray-700 font-medium">
                Failure_Ratio
              </span>
            </div>
          </div>
        </div>

        {/* 중앙 – 최근 3개월 도넛 차트 */}
        <div className="w-[34%] flex flex-col items-center">
          <h3 className="w-full text-sm font-semibold text-gray-800 mb-4">
            COQ 비율 구조 (최근 3개월)
          </h3>
          <div className="w-full flex-1 flex items-center justify-center">
            <ResponsiveContainer width="100%" height={230}>
              <PieChart>
                <Pie
                  data={recentPieData}
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                >
                  <Cell fill="#d1d5db" /> {/* P – 회색 */}
                  <Cell fill="#111827" /> {/* A – 검정 */}
                  <Cell fill="#ef4444" /> {/* F – 빨강 */}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-1 space-y-1 text-xs text-gray-700 self-start pl-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#d1d5db]" />
              <span>Prevention (P)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#111827]" />
              <span>Appraisal (A)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" />
              <span>Failure (F)</span>
            </div>
          </div>
        </div>

        {/* 오른쪽 – P/A/F 최적 비율 카드 3개 */}
        <div className="w-[22%] flex flex-col gap-4 justify-center">
          <RatioCard
            label="Prevention (P)"
            value="0.5"
            delta="+0.3%"
            direction="up"
          />
          <RatioCard
            label="Appraisal (A)"
            value="0.5"
            delta="+4%"
            direction="up"
          />
          <RatioCard
            label="Failure (F)"
            value="0.5"
            delta="-2%"
            direction="down"
          />
        </div>
      </motion.section>

      {/* 하단 레이아웃: KEY INSIGHTS / Efficiency / Timeline */}
      <section className="grid grid-cols-[1.3fr_2fr_1.1fr] gap-6">
        {/* KEY INSIGHTS 카드 */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="bg-white rounded-[32px] shadow-lg px-7 py-6 flex flex-col"
        >
          <h3 className="text-sm font-semibold text-gray-800 mb-4">
            KEY INSIGHTS
          </h3>
          <div className="flex-1 flex flex-col gap-4">
            {[0, 1, 2].map((idx) => (
              <div
                key={idx}
                className="flex-1 rounded-2xl bg-[#fef2f2] border border-[#fee2e2] shadow-inner"
              />
            ))}
          </div>
        </motion.div>

        {/* COQ Efficiency 라인차트 */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.4 }}
          className="bg-white rounded-[32px] shadow-lg px-7 py-6 flex flex-col"
        >
          <h3 className="text-sm font-semibold text-gray-800 mb-4">
            COQ Efficiency
          </h3>
          <div className="flex-1">
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={efficiencyData}>
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="rgba(0,0,0,0.06)"
                />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 10, fill: "#737373" }}
                  axisLine={{ stroke: "#e5e7eb" }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "#737373" }}
                  axisLine={{ stroke: "#e5e7eb" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(255,255,255,0.95)",
                    borderRadius: 16,
                    border: "1px solid rgba(0,0,0,0.08)",
                    padding: "10px 12px",
                  }}
                  labelStyle={{ fontSize: 11, color: "#4b5563" }}
                  itemStyle={{ fontSize: 11, color: "#111827" }}
                />
                <Line
                  type="monotone"
                  dataKey="efficiency"
                  stroke="#ef4444"
                  strokeWidth={2}
                  dot={{ r: 2, fill: "#ef4444" }}
                  activeDot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Efficiency Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
          className="bg-white rounded-[32px] shadow-lg px-7 py-6 flex flex-col"
        >
          <h3 className="text-sm font-semibold text-gray-800 mb-4">
            Efficiency Timeline
          </h3>
          <div className="flex-1 flex flex-col gap-3 mt-1">
            {timeline.map((item) => {
              const isGood = item.status === "개선";
              const isStable = item.status === "안정";

              const dotColor = isGood
                ? "bg-red-500"
                : isStable
                ? "bg-green-400"
                : "bg-gray-400";

              const badgeBg = isGood
                ? "bg-red-100 text-red-700 border-red-200"
                : isStable
                ? "bg-green-100 text-green-700 border-green-200"
                : "bg-gray-100 text-gray-700 border-gray-200";

              return (
                <div key={item.year} className="flex items-center gap-4">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${dotColor}`}
                  ></span>
                  <span className="text-xs font-medium text-gray-800 w-10">
                    {item.year}
                  </span>
                  <div className="flex-1 h-px bg-gray-200" />
                  <span
                    className={`text-[11px] px-3 py-1 rounded-xl border font-semibold ${badgeBg}`}
                  >
                    {item.status}
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      </section>
    </div>
  );
}
