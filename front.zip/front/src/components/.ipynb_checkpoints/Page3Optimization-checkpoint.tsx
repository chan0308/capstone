// src/components/Page3Optimization.tsx
import { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
  ReferenceDot,
  ReferenceLine,
  Cell,
} from "recharts";

type CoqRatio = {
  p: number; // Prevention
  a: number; // Appraisal
  f: number; // Failure
};

type CoqBarItem = {
  name: string;
  value: number;
};

type ImprovementStep = {
  stepIndex: number;
  stepLabel: string;
  coq: number;
};

type AnnotationPoint = {
  x: number;
  y: number;
  label: string;
};

type GradientPoint = {
  a: number;   // Appraisal Ratio
  coq: number; // Predicted COQ
};

const INITIAL_COQ: CoqRatio = {
  p: 0.12,
  a: 0.44, // 🔴 현재 Appraisal 비율(설명용 그래프와 맞춤)
  f: 0.28,
};

const OPTIMAL_COQ: CoqRatio = {
  p: 0.23,
  a: 0.42,
  f: 0.34,
};

const THEORETICAL_COQ: CoqRatio = {
  p: 0.3,
  a: 0.45,
  f: 0.25,
};

function calcTotalCoq(r: CoqRatio): number {
  return r.p + r.a + r.f;
}

function clamp01(x: number): number {
  return Math.min(1, Math.max(0, x));
}

export default function Page3Optimization() {
  const [coq, setCoq] = useState<CoqRatio>(INITIAL_COQ);

  const handleSliderChange =
    (key: keyof CoqRatio) =>
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const v = Number(e.target.value);
      setCoq((prev) => ({ ...prev, [key]: clamp01(v) }));
    };

  const coqBarData: CoqBarItem[] = [
    { name: "COQ ratio", value: calcTotalCoq(coq) },
    { name: "P", value: coq.p },
    { name: "A", value: coq.a },
    { name: "F", value: coq.f },
  ];

  const initialTotal = calcTotalCoq(INITIAL_COQ);
  const currentTotal = calcTotalCoq(coq);
  const optimalTotal = calcTotalCoq(OPTIMAL_COQ);
  const totalImprovement =
    ((initialTotal - currentTotal) / initialTotal) * 100;

  // ===============================
  // Nonlinear COQ curve (Python 그래프 모양 근사)
  // ===============================
  const gradientPoints: GradientPoint[] = [
    // 왼쪽 평탄 구간
    { a: 0.20, coq: 1.26 },
    { a: 0.25, coq: 1.26 },
    { a: 0.30, coq: 1.26 },
    { a: 0.34, coq: 1.26 },
    { a: 0.36, coq: 1.25 },
    { a: 0.38, coq: 1.23 },
    { a: 0.39, coq: 1.22 },
    { a: 0.40, coq: 1.22 }, // ✅ Optimal 근처 작은 바닥
    // 서서히 상승 구간
    { a: 0.41, coq: 1.24 },
    { a: 0.42, coq: 1.27 },
    { a: 0.43, coq: 1.35 },
    { a: 0.44, coq: 1.49 },
    // 무릎(knee) 이후 급상승 + 약간의 요철
    { a: 0.455, coq: 1.80 },
    { a: 0.465, coq: 1.95 },
    { a: 0.475, coq: 2.10 },
    { a: 0.485, coq: 2.00 },
    { a: 0.495, coq: 2.20 },
    { a: 0.50, coq: 3.10 },
    { a: 0.51, coq: 3.25 },
    { a: 0.52, coq: 3.30 },
    { a: 0.56, coq: 3.33 },
  ];

  const GRADIENT_A_MIN = gradientPoints[0].a;
  const GRADIENT_A_MAX = gradientPoints[gradientPoints.length - 1].a;

  // 설명용 현재/최적 지점 (Python 그림 위치 기준)
  const VISUAL_CURRENT_A = 0.44;
  const VISUAL_OPTIMAL_A = 0.40;

  // A값에 대해 gradientPoints 사이 선형보간
  const predictCoqFromAppraisal = (a: number): number => {
    const pts = gradientPoints;
    if (a <= pts[0].a) return pts[0].coq;
    if (a >= pts[pts.length - 1].a) return pts[pts.length - 1].coq;

    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i];
      const p1 = pts[i + 1];
      if (a >= p0.a && a <= p1.a) {
        const t = (a - p0.a) / (p1.a - p0.a);
        return p0.coq + t * (p1.coq - p0.coq);
      }
    }
    return pts[0].coq;
  };

  const gradientCurveData = gradientPoints;

  // 점 위치 계산 (Current는 선보다 조금 위, Optimal은 선 위에)
  const optimalCoqPred = predictCoqFromAppraisal(VISUAL_OPTIMAL_A);
  const currentCoqBase = predictCoqFromAppraisal(VISUAL_CURRENT_A);
  const currentCoqPred = currentCoqBase + 0.2; // 🔴 선보다 약간 위로 띄움

  // Cost Saving 표시용 값들 (수평 점선 + 수직 화살표)
  const COST_SAVING_X = 0.29;
  const costSavingYTop = currentCoqBase;
  const costSavingYBottom = optimalCoqPred;

  // Which change reduces COQ the most? 데이터
  const improvementSteps: ImprovementStep[] = [
    { stepIndex: 0, stepLabel: "현재", coq: 1.53 },
    { stepIndex: 1, stepLabel: "A 조정", coq: 1.31 },
    { stepIndex: 2, stepLabel: "P 조정", coq: 1.19 },
  ];

  const annotationPoints: AnnotationPoint[] = [
    {
      x: 0.5,
      y: (1.53 + 1.31) / 2,
      label: "▼ A -10%",
    },
    {
      x: 1.5,
      y: (1.31 + 1.19) / 2,
      label: "▼ P -5%",
    },
  ];

  const stepLabelMap: Record<number, string> = {
    0: "현재",
    1: "A 조정",
    2: "P 조정",
  };

  // What drives bad COQ? 데이터 (색 포함)
  const driverData = [
    { name: "Prevention", value: 0.9, fill: "#9ca3af" }, // 회색
    { name: "Appraisal", value: 1.6, fill: "#ef4444" }, // 빨강
    { name: "Failure", value: -1.8, fill: "#22c55e" }, // 연두
  ];

  return (
    <div className="min-h-[calc(100vh-80px)] bg-neutral-50 px-10 py-8">
      {/* 상단 헤더 + 4 카드 */}
      <div className="mb-8 flex items-start justify-between gap-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-black">
            Quality Cost Optimization
          </h1>
          <p className="mt-1 text-sm text-gray-600">
            Where Should Tesla Move? (Optimal Ratio)
          </p>
        </div>

        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Optimized COQ", value: optimalTotal.toFixed(2) },
            { label: "Prevention (P)", value: OPTIMAL_COQ.p.toFixed(2) },
            { label: "Appraisal (A)", value: OPTIMAL_COQ.a.toFixed(2) },
            { label: "Failure (F)", value: OPTIMAL_COQ.f.toFixed(2) },
          ].map((card, idx) => (
            <div
              key={idx}
              className="rounded-2xl bg-white px-4 py-3 shadow-md border border-gray-100"
            >
              <p className="text-xs text-gray-500">{card.label}</p>
              <p className="mt-1 text-2xl font-bold text-red-600">
                {card.value}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* 중단: Simulation / Gradient Curve / Key Insights */}
      <div className="mb-6 grid grid-cols-[minmax(0,2fr)_minmax(0,1.5fr)_minmax(0,1.2fr)] gap-6">
        {/* Simulation */}
        <div className="rounded-3xl bg-white p-5 shadow-md border border-gray-100">
          <h2 className="mb-4 text-sm font-semibold text-gray-800">
            COQ Optimizing Simulation
          </h2>
          <div className="grid grid-cols-[minmax(0,2fr)_220px] gap-6">
            {/* COQ ratio + P/A/F 수평 막대 */}
            <div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={coqBarData} layout="vertical">
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#e5e5e5"
                    horizontal={false}
                  />
                  <XAxis
                    type="number"
                    domain={[0, 2]}
                    stroke="#9ca3af"
                    tick={{ fontSize: 10 }}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    stroke="#4b5563"
                    width={60}
                    tick={{ fontSize: 11, fontWeight: 600 }}
                  />
                  <Tooltip
                    contentStyle={{
                      fontSize: 12,
                      borderRadius: 12,
                    }}
                  />
                  <Bar dataKey="value" radius={[4, 4, 4, 4]} fill="#ef4444" />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-4 space-y-1 text-xs text-gray-600">
                <p>
                  • 현재 COQ 비율:{" "}
                  <span className="font-semibold text-red-600">
                    {currentTotal.toFixed(2)}
                  </span>{" "}
                  (초기: {initialTotal.toFixed(2)})
                </p>
                <p>
                  • 최종 COQ 개선률:{" "}
                  <span className="font-semibold text-red-600">
                    {totalImprovement.toFixed(1)}%
                  </span>
                </p>
              </div>
            </div>

            {/* 슬라이더 박스 */}
            <div className="rounded-2xl border border-gray-100 bg-neutral-50 px-4 py-3 shadow-inner">
              <p className="mb-2 text-xs font-semibold text-gray-700">
                Adjust COQ Ratio
              </p>

              <div className="space-y-4">
                {/* P */}
                <div>
                  <div className="mb-1 flex items-center justify-between text-[10px] text-gray-600">
                    <span>Prevention (P)</span>
                    <span className="font-semibold text-gray-800">
                      {coq.p.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.6}
                    step={0.01}
                    value={coq.p}
                    onChange={handleSliderChange("p")}
                    className="w-full accent-red-500"
                  />
                </div>

                {/* A */}
                <div>
                  <div className="mb-1 flex items-centered justify-between text-[10px] text-gray-600">
                    <span>Appraisal (A)</span>
                    <span className="font-semibold text-gray-800">
                      {coq.a.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.8}
                    step={0.01}
                    value={coq.a}
                    onChange={handleSliderChange("a")}
                    className="w-full accent-red-500"
                  />
                </div>

                {/* F */}
                <div>
                  <div className="mb-1 flex items-center justify-between text-[10px] text-gray-600">
                    <span>Failure (F)</span>
                    <span className="font-semibold text-gray-800">
                      {coq.f.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={0.8}
                    step={0.01}
                    value={coq.f}
                    onChange={handleSliderChange("f")}
                    className="w-full accent-red-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Nonlinear COQ curve (Current vs Optimal) */}
        <div className="rounded-3xl bg-white p-5 shadow-md border border-gray-100">
          <h2 className="mb-1 text-sm font-semibold text-gray-800">
            Nonlinear COQ Curve using Gradient Boosting
          </h2>
          <p className="mb-4 text-xs text-gray-500">
            Current vs Optimal Point (Appraisal Ratio A)
          </p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart
              data={gradientCurveData}
              margin={{ top: 10, right: 16, bottom: 4, left: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis
                type="number"
                dataKey="a"
                domain={[GRADIENT_A_MIN, GRADIENT_A_MAX]}
                tickFormatter={(value: number) => value.toFixed(2)}
                stroke="#6b7280"
                tick={{ fontSize: 11 }}
                label={{
                  value: "Appraisal Ratio (A)",
                  position: "insideBottom",
                  offset: -2,
                  style: { fontSize: 11, fill: "#4b5563" },
                }}
              />
              <YAxis
                dataKey="coq"
                domain={[1.15, 3.4]}
                stroke="#9ca3af"
                tick={{ fontSize: 11 }}
                label={{
                  value: "Predicted COQ Ratio",
                  angle: -90,
                  position: "insideLeft",
                  style: { fontSize: 11, fill: "#4b5563" },
                }}
              />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 12 }}
                formatter={(value: any) => [value, "COQ"]}
                labelFormatter={(label: any) =>
                  `Appraisal Ratio A = ${(label as number).toFixed(2)}`
                }
              />
              {/* 선형 연결로 Python 그래프처럼 꺾이게 */}
              <Line
                type="linear"
                dataKey="coq"
                name="Predicted COQ (GBR)"
                stroke="#2563eb"
                strokeWidth={2}
                dot={false}
              />

              {/* Cost Saving: 위/아래 수평 점선 */}
              <ReferenceLine
                y={costSavingYTop}
                stroke="#111827"
                strokeDasharray="4 2"
              />
              <ReferenceLine
                y={costSavingYBottom}
                stroke="#111827"
                strokeDasharray="4 2"
              />
              {/* Cost Saving: 수직 주황선 + 라벨 */}
              <ReferenceLine
                segment={[
                  { x: COST_SAVING_X, y: costSavingYBottom },
                  { x: COST_SAVING_X, y: costSavingYTop },
                ]}
                stroke="#f59e0b"
                strokeWidth={2}
                label={{
                  value: "Cost Saving",
                  position: "left",
                  fill: "#f59e0b",
                  fontSize: 11,
                }}
              />

              {/* Current point (red) - 선보다 위에 (라벨 없음) */}
              <ReferenceDot
                x={VISUAL_CURRENT_A}
                y={currentCoqPred}
                r={6}
                fill="#ef4444"
                stroke="#ffffff"
                isFront
              />

              {/* Optimal point (green) - 선 위에 (라벨 없음) */}
              <ReferenceDot
                x={VISUAL_OPTIMAL_A}
                y={optimalCoqPred}
                r={7}
                fill="#22c55e"
                stroke="#ffffff"
                isFront
              />

              {/* 상단 범례용 점 + 레이블 */}
              <ReferenceDot
                x={GRADIENT_A_MIN + 0.035} // 왼쪽 위 근처
                y={3.35}
                r={5}
                fill="#ef4444"
                stroke="#ffffff"
                isFront
                label={{
                  value: "Current COQ",
                  position: "right",
                  fill: "#ef4444",
                  fontSize: 11,
                }}
              />
              <ReferenceDot
                x={GRADIENT_A_MIN + 0.19} // 그 옆
                y={3.35}
                r={5}
                fill="#22c55e"
                stroke="#ffffff"
                isFront
                label={{
                  value: "Optimal COQ",
                  position: "right",
                  fill: "#16a34a",
                  fontSize: 11,
                }}
              />

              {/* Current → Optimal 방향 화살표(점선 + 라벨) */}
              <ReferenceLine
                segment={[
                  { x: VISUAL_CURRENT_A, y: currentCoqPred },
                  { x: VISUAL_OPTIMAL_A, y: optimalCoqPred },
                ]}
                stroke="#16a34a"
                strokeWidth={2}
                strokeDasharray="4 2"
                label={{
                  value: "↓ COQ 감소 방향",
                  position: "insideRight",
                  fill: "#16a34a",
                  fontSize: 11,
                }}
              />

              <Legend wrapperStyle={{ fontSize: 11 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Key Insights */}
        <div className="flex h-full flex-col gap-3 rounded-3xl bg-white p-5 shadow-md border border-gray-100">
          <h2 className="text-sm font-semibold text-gray-800">Key Insights</h2>
          <textarea
            className="flex-1 resize-none rounded-xl border border-gray-200 bg-neutral-50 px-3 py-2 text-xs text-gray-700 outline-none focus:ring-1 focus:ring-red-400"
            placeholder="- 예: A 10% 감소가 COQ에 가장 큰 기여\n- 예: P 5% 증가는 보조적인 역할"
          />
          <textarea
            className="flex-1 resize-none rounded-xl border border-gray-200 bg-neutral-50 px-3 py-2 text-xs text-gray-700 outline-none focus:ring-1 focus:ring-red-400"
            placeholder="- Simulation 결과에 따른 추가 인사이트를 메모하세요."
          />
          <textarea
            className="flex-1 resize-none rounded-xl border border-gray-200 bg-neutral-50 px-3 py-2 text-xs text-gray-700 outline-none focus:ring-1 focus:ring-red-400"
            placeholder="- 향후 Prevention 투자 전략 등"
          />
        </div>
      </div>

      {/* 하단 두 블록 */}
      <div className="grid grid-cols-2 gap-6">
        {/* What drives bad COQ? */}
        <div className="rounded-3xl bg-white p-5 shadow-md border border-gray-100">
          <h2 className="mb-4 text-sm font-semibold text-gray-800">
            What drives bad COQ?
          </h2>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2 text-xs text-gray-700">
              <p className="font-semibold">
                • A 10% 감소가 COQ 최적화에 가장 강력한 효과
              </p>
              <p>• P 5% 증가는 보조적인 보완 효과</p>
              <p>• 최종 COQ는 1.53 → 1.19로 약 22% 개선</p>
            </div>
            <div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={driverData}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#e5e5e5"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="name"
                    stroke="#6b7280"
                    tick={{ fontSize: 11 }}
                  />
                  <YAxis
                    stroke="#9ca3af"
                    tick={{ fontSize: 10 }}
                    domain={[-2.2, 2.2]}
                  />
                  <Tooltip
                    contentStyle={{
                      fontSize: 12,
                      borderRadius: 12,
                    }}
                  />
                  <Bar dataKey="value">
                    {driverData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Which change reduces COQ the most? */}
        <div className="rounded-3xl bg-white p-5 shadow-md border border-gray-100">
          <h2 className="mb-4 text-sm font-semibold text-gray-800">
            Which change reduces COQ the most?
          </h2>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={improvementSteps}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />
                  <XAxis
                    type="number"
                    dataKey="stepIndex"
                    domain={[0, 2]}
                    ticks={[0, 1, 2]}
                    stroke="#6b7280"
                    tick={{ fontSize: 11 }}
                    tickFormatter={(v) =>
                      stepLabelMap[Math.round(v as number)] ?? ""
                    }
                  />
                  <YAxis
                    stroke="#9ca3af"
                    tick={{ fontSize: 10 }}
                    domain={[1.1, 1.6]}
                  />
                  <Tooltip
                    contentStyle={{
                      fontSize: 12,
                      borderRadius: 12,
                    }}
                    formatter={(value: any) => [value, "COQ"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="coq"
                    stroke="#ef4444"
                    strokeWidth={2}
                    dot={{ r: 4, stroke: "#111827", fill: "#111827" }}
                    activeDot={{ r: 5, stroke: "#111827", fill: "#111827" }}
                  />
                  {/* 선분 중앙에 메모 */}
                  <ReferenceDot
                    x={annotationPoints[0].x}
                    y={annotationPoints[0].y}
                    r={0}
                    isFront
                    label={{
                      value: annotationPoints[0].label,
                      position: "top",
                      fill: "#ef4444",
                      fontSize: 12,
                    }}
                  />
                  <ReferenceDot
                    x={annotationPoints[1].x}
                    y={annotationPoints[1].y}
                    r={0}
                    isFront
                    label={{
                      value: annotationPoints[1].label,
                      position: "top",
                      fill: "#ef4444",
                      fontSize: 12,
                    }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col justify-center space-y-2 text-xs text-gray-700">
              <p className="font-semibold">
                • A 10% 감소가 COQ 개선에 가장 크게 기여
              </p>
              <p>• P 5% 증가는 보조적인 역할</p>
              <p>• 총 COQ는 1.53 → 1.19로 약 22% 개선</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
