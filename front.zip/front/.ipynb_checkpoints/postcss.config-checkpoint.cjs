// C:\Users\secha\capstone\front\postcss.config.cjs

module.exports = {
  plugins: {
    tailwindcss: {},      // ✅ Tailwind 3에서는 이걸 사용
    autoprefixer: {},
  },
};
