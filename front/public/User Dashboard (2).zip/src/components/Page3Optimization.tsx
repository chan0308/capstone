import { useState, useRef } from "react";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  Cell,
} from "recharts";

/* ============================================================
   CUSTOM HORIZONTAL SLIDER COMPONENT
============================================================ */
function HorizontalSlider({
  label,
  value,
  setValue,
  min,
  max,
  color,
}: {
  label: string;
  value: number;
  setValue: (v: number) => void;
  min: number;
  max: number;
  color: string;
}) {
  const trackRef = useRef<HTMLDivElement | null>(null);

  const handleDrag = (clientX: number) => {
    if (!trackRef.current) return;

    const rect = trackRef.current.getBoundingClientRect();
    const offset = clientX - rect.left;
    const ratio = Math.min(Math.max(offset / rect.width, 0), 1);
    const newValue = min + ratio * (max - min);

    setValue(parseFloat(newValue.toFixed(2)));
  };

  const startDrag = (e: any) => {
    e.preventDefault();
    handleDrag(e.clientX || e.touches?.[0]?.clientX);

    const move = (ev: any) =>
      handleDrag(ev.clientX || ev.touches?.[0]?.clientX);
    const stop = () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("touchmove", move);
      window.removeEventListener("mouseup", stop);
      window.removeEventListener("touchend", stop);
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("touchmove", move);
    window.addEventListener("mouseup", stop);
    window.addEventListener("touchend", stop);
  };

  const percent = ((value - min) / (max - min)) * 100;

  return (
    <div className="flex items-center gap-3">
      <span className="text-xs font-semibold text-gray-700 w-20">
        {label}
      </span>

      <div className="flex items-center gap-2 flex-1">
        <div
          ref={trackRef}
          className="relative h-2 bg-gray-200 rounded-full flex-1"
        >
          <div
            className="absolute left-0 top-0 h-full rounded-full"
            style={{
              width: `${percent}%`,
              backgroundColor: color,
            }}
          />
          <div
            onMouseDown={startDrag}
            onTouchStart={startDrag}
            className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 shadow rounded-full cursor-pointer"
            style={{
              left: `calc(${percent}% - 8px)`,
              borderColor: color,
            }}
          />
        </div>

        <span className="text-xs font-semibold text-gray-800 w-10 text-right">
          {value.toFixed(2)}
        </span>
      </div>
    </div>
  );
}

/* ============================================================
   MAIN PAGE 3 — 1600px 기반 반응형 레이아웃
============================================================ */
export default function Page3Optimization() {
  const [pValue, setPValue] = useState(0.12);
  const [aValue, setAValue] = useState(0.53);
  const [fValue, setFValue] = useState(0.35);

  const calculateCOQ = (p: number, a: number, f: number) =>
    Math.max(
      0.5,
      Math.min(
        5,
        3.5 + 1.12 * p * 10 - 2.84 * a * 10 - 0.95 * f * 10,
      ),
    );

  const currentCOQ = calculateCOQ(pValue, aValue, fValue);

  const optimalP = 0.23;
  const optimalA = 0.42;
  const optimalF = 0.34;
  const optimalCOQ = 0.5;

  const coqBarData = [
    { name: "COQ ratio", value: currentCOQ, color: "#dc2626" },
    { name: "P", value: pValue, color: "#6b7280" },
    { name: "A", value: aValue, color: "#525252" },
    { name: "F", value: fValue, color: "#737373" },
  ];

  const elasticNetData = [
    { label: "Prevention", coefficient: 1, color: "#9ca3af" },
    { label: "Appraisal", coefficient: 2, color: "#dc2626" },
    { label: "Failure", coefficient: -1, color: "#22c55e" },
  ];

  const sensitivityData = [
    { label: "변경", a: 2.0, p: 1.8, f: 1.9 },
    { label: "A -10%", a: 1.5, p: null, f: null },
    { label: "P -5%", a: null, p: 1.6, f: null },
    { label: "P +5%", a: null, p: null, f: 2.1 },
  ];

  const radarData = [
    {
      metric: "Prevention",
      Current: pValue,
      Optimal: optimalP,
      Theoretical: 0.3,
    },
    {
      metric: "Appraisal",
      Current: aValue,
      Optimal: optimalA,
      Theoretical: 0.2,
    },
    {
      metric: "Failure",
      Current: fValue,
      Optimal: optimalF,
      Theoretical: 0.5,
    },
  ];

  return (
    <div className="w-full flex justify-center">
      <div className="w-full max-w-[1600px] px-6 py-12">

        {/* HEADER */}
        <div className="mb-10">
          <h1 className="text-5xl font-bold text-black mb-2">
            Quality Cost Optimization
          </h1>
          <h2 className="text-lg font-semibold">
            <span className="text-red-600">Where Should Tesla Move?</span>
            <span className="text-gray-700"> (Optimal Ratio)</span>
          </h2>
        </div>

        {/* TOP ROW */}
        <div className="grid grid-cols-[1fr,320px] gap-8 mb-10">
          <div className="grid grid-cols-4 gap-6">
            {[
              ["Optimized COQ", optimalCOQ.toFixed(1)],
              ["Prevention (P)", optimalP.toFixed(2)],
              ["Appraisal (A)", optimalA.toFixed(2)],
              ["Failure (F)", optimalF.toFixed(2)],
            ].map(([label, val], idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 text-center"
              >
                <div className="text-xs text-gray-500 mb-1">{label}</div>
                <div className="text-4xl font-bold text-red-600">
                  {val}
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl border shadow-sm p-6">
            <h3 className="text-base font-bold mb-4">Key Insights</h3>
            <div className="space-y-3">
              <div className="h-12 rounded-lg bg-gray-100"></div>
              <div className="h-12 rounded-lg bg-gray-100"></div>
              <div className="h-12 rounded-lg bg-gray-100"></div>
            </div>
          </div>
        </div>

        {/* MIDDLE ROW */}
        <div className="grid grid-cols-[1fr,430px] gap-8 mb-10">
          {/* SIMULATION */}
          <div className="bg-white rounded-2xl border shadow-sm p-6">
            <h3 className="text-base font-bold mb-6">
              COQ Optimizing Simulation
            </h3>

            <div className="grid grid-cols-[1fr,220px] gap-6">
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={coqBarData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 3.5]} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {coqBarData.map((e, i) => (
                      <Cell key={i} fill={e.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              <div className="flex flex-col justify-center space-y-4">
                <HorizontalSlider
                  label="Prevention"
                  value={pValue}
                  setValue={setPValue}
                  min={0.1}
                  max={0.3}
                  color="#6b7280"
                />
                <HorizontalSlider
                  label="Appraisal"
                  value={aValue}
                  setValue={setAValue}
                  min={0.2}
                  max={0.6}
                  color="#525252"
                />
                <HorizontalSlider
                  label="Failure"
                  value={fValue}
                  setValue={setFValue}
                  min={0.2}
                  max={0.5}
                  color="#737373"
                />
              </div>
            </div>
          </div>

          {/* RADAR */}
          <div className="bg-white rounded-2xl border shadow-sm p-6">
            <div className="flex justify-center gap-4 text-xs mb-3">
              <div className="flex items-center gap-1">
                <span className="w-3 h-3 bg-pink-500 rounded-full" />
                Current
              </div>
              <div className="flex items-center gap-1">
                <span className="w-3 h-3 bg-yellow-400 rounded-full" />
                Optimal
              </div>
              <div className="flex items-center gap-1">
                <span className="w-3 h-3 bg-blue-400 rounded-full" />
                Theoretical
              </div>
            </div>

            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="metric" />
                <PolarRadiusAxis angle={90} domain={[0, 0.6]} />
                <Radar
                  name="Current"
                  dataKey="Current"
                  stroke="#ec4899"
                  fill="#ec4899"
                  fillOpacity={0.3}
                />
                <Radar
                  name="Optimal"
                  dataKey="Optimal"
                  stroke="#facc15"
                  fill="#facc15"
                  fillOpacity={0.25}
                />
                <Radar
                  name="Theoretical"
                  dataKey="Theoretical"
                  stroke="#60a5fa"
                  fill="#60a5fa"
                  fillOpacity={0.2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* BOTTOM ROW */}
        <div className="grid grid-cols-2 gap-8">
          {/* DRIVERS */}
          <div className="bg-white rounded-2xl border shadow-sm p-6">
            <h3 className="text-base font-bold mb-6">
              What drives bad COQ?
            </h3>

            <div className="grid grid-cols-[1fr,220px] gap-6">
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={elasticNetData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="label" />
                  <YAxis domain={[-2, 2]} />
                  <Tooltip />
                  <Bar dataKey="coefficient" radius={[4, 4, 0, 0]}>
                    {elasticNetData.map((e, i) => (
                      <Cell key={i} fill={e.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>

              <div className="text-xs flex flex-col justify-center gap-1 text-gray-700">
                <p>• A -10% 감소가 COQ 가장 큰 개선</p>
                <p>• P 5% 조정은 보조적</p>
                <p>• COQ 1.53 → 1.19 (22% 개선)</p>
              </div>
            </div>
          </div>

          {/* SENSITIVITY */}
          <div className="bg-white rounded-2xl border shadow-sm p-6">
            <h3 className="text-base font-bold mb-6">
              Which change reduces COQ the most?
            </h3>

            <div className="grid grid-cols-[1fr,220px] gap-6">
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={sensitivityData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="label" />
                  <YAxis domain={[1.0, 2.3]} />
                  <Tooltip />
                  <Line
                    dataKey="a"
                    stroke="#dc2626"
                    dot={{ r: 4, fill: "#dc2626" }}
                  />
                  <Line
                    dataKey="p"
                    stroke="#525252"
                    dot={{ r: 4, fill: "#525252" }}
                  />
                  <Line
                    dataKey="f"
                    stroke="#737373"
                    dot={{ r: 4, fill: "#737373" }}
                  />
                </LineChart>
              </ResponsiveContainer>

              <div className="text-xs flex flex-col justify-center gap-1 text-gray-700">
                <p>• A -10%가 가장 큰 개선</p>
                <p>• P -5%는 보조적</p>
                <p>• COQ: 1.53 → 1.19</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
